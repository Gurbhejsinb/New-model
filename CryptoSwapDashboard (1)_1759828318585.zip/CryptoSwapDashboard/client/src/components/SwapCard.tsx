import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowDownUp } from "lucide-react";
import TokenInput from "./TokenInput";

interface SwapCardProps {
  fromAmount: string;
  toAmount: string;
  onFromAmountChange: (value: string) => void;
  balance: string;
  onMaxClick: () => void;
  onSwap: () => void;
  isConnected: boolean;
  isSwapping: boolean;
  conversionRate: number;
  isPriceLoading: boolean;
}

export default function SwapCard({
  fromAmount,
  toAmount,
  onFromAmountChange,
  balance,
  onMaxClick,
  onSwap,
  isConnected,
  isSwapping,
  conversionRate,
  isPriceLoading,
}: SwapCardProps) {
  const hasInsufficientBalance = isConnected && parseFloat(fromAmount) > parseFloat(balance);
  const isSwapDisabled = !isConnected || !fromAmount || parseFloat(fromAmount) <= 0 || hasInsufficientBalance || isSwapping;

  return (
    <Card className="p-6 max-w-md w-full shadow-2xl">
      <div className="space-y-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Swap</h2>
          <div className="text-xs text-muted-foreground" data-testid="text-conversion-rate">
            {isPriceLoading ? (
              <span className="animate-pulse">Loading...</span>
            ) : (
              <span>1 BNB = {conversionRate.toFixed(2)} USDT</span>
            )}
          </div>
        </div>

        <TokenInput
          label="From"
          value={fromAmount}
          onChange={onFromAmountChange}
          tokenSymbol="BNB"
          balance={isConnected ? balance : undefined}
          onMaxClick={isConnected ? onMaxClick : undefined}
        />

        <div className="flex justify-center -my-2">
          <div className="w-10 h-10 rounded-full border-4 border-background bg-accent flex items-center justify-center hover-elevate active-elevate-2">
            <ArrowDownUp className="w-4 h-4 text-muted-foreground" />
          </div>
        </div>

        <TokenInput
          label="To"
          value={toAmount}
          onChange={() => {}}
          tokenSymbol="USDT"
          readOnly
        />

        {hasInsufficientBalance && (
          <p className="text-sm text-destructive" data-testid="text-insufficient-balance">
            Insufficient BNB balance
          </p>
        )}

        <Button
          className="w-full py-6 text-base font-semibold"
          onClick={onSwap}
          disabled={isSwapDisabled}
          data-testid="button-swap"
        >
          {!isConnected
            ? "Connect Wallet"
            : isSwapping
            ? "Swapping..."
            : hasInsufficientBalance
            ? "Insufficient Balance"
            : "Swap"}
        </Button>

        <div className="pt-2 space-y-1 text-xs text-muted-foreground">
          <div className="flex justify-between">
            <span>Network</span>
            <span className="font-medium">BSC Testnet</span>
          </div>
          <div className="flex justify-between">
            <span>Swap Fee</span>
            <span className="font-medium">0.3%</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
