import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ArrowDown, AlertCircle } from "lucide-react";

interface ConfirmSwapModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  fromAmount: string;
  toAmount: string;
  isConfirming: boolean;
  conversionRate: number;
}

export default function ConfirmSwapModal({
  open,
  onClose,
  onConfirm,
  fromAmount,
  toAmount,
  isConfirming,
  conversionRate,
}: ConfirmSwapModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Confirm Swap</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="bg-accent rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">From</span>
              <div className="text-right">
                <p className="text-lg font-semibold" data-testid="text-confirm-from-amount">
                  {fromAmount} BNB
                </p>
              </div>
            </div>
            
            <div className="flex justify-center">
              <div className="w-8 h-8 rounded-full bg-background flex items-center justify-center">
                <ArrowDown className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">To</span>
              <div className="text-right">
                <p className="text-lg font-semibold" data-testid="text-confirm-to-amount">
                  {toAmount} USDT
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rate</span>
              <span className="font-medium">1 BNB = {conversionRate.toFixed(2)} USDT</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Fee (0.3%)</span>
              <span className="font-medium">~0.003 BNB</span>
            </div>
          </div>

          <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 flex gap-3">
            <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            <p className="text-xs text-destructive">
              Output is estimated. You will receive at least {toAmount} USDT or the transaction will revert.
            </p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isConfirming}
            data-testid="button-cancel-swap"
          >
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
            disabled={isConfirming}
            data-testid="button-confirm-swap"
          >
            {isConfirming ? "Confirming..." : "Confirm Swap"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
