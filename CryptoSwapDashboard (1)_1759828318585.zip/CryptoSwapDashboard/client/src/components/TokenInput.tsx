import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface TokenInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  tokenSymbol: string;
  balance?: string;
  onMaxClick?: () => void;
  readOnly?: boolean;
}

export default function TokenInput({
  label,
  value,
  onChange,
  tokenSymbol,
  balance,
  onMaxClick,
  readOnly = false,
}: TokenInputProps) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </label>
        {balance && (
          <span className="text-xs text-muted-foreground" data-testid={`text-balance-${tokenSymbol.toLowerCase()}`}>
            Balance: {parseFloat(balance).toFixed(4)} {tokenSymbol}
          </span>
        )}
      </div>
      <div className="bg-accent rounded-xl p-4 border border-accent-border">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="flex items-center gap-2 px-3 py-2 bg-background rounded-lg">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-xs font-bold text-primary">
                  {tokenSymbol.charAt(0)}
                </span>
              </div>
              <span className="font-medium text-sm">{tokenSymbol}</span>
            </div>
            <Input
              type="number"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="0.0"
              readOnly={readOnly}
              className="border-0 bg-transparent text-2xl font-medium p-0 h-auto focus-visible:ring-0 focus-visible:ring-offset-0"
              data-testid={`input-${label.toLowerCase()}-amount`}
            />
          </div>
          {onMaxClick && (
            <Button
              variant="outline"
              size="sm"
              onClick={onMaxClick}
              className="shrink-0"
              data-testid="button-max"
            >
              Max
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
