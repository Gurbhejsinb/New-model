import { Button } from "@/components/ui/button";
import { Wallet } from "lucide-react";
import { shortenAddress } from "@/lib/wallet";

interface WalletConnectProps {
  address: string | null;
  isConnecting: boolean;
  onConnect: () => void;
}

export default function WalletConnect({ address, isConnecting, onConnect }: WalletConnectProps) {
  if (address) {
    return (
      <div 
        className="flex items-center gap-2 px-4 py-2 bg-accent rounded-xl border border-accent-border"
        data-testid="text-wallet-address"
      >
        <div className="w-2 h-2 bg-chart-2 rounded-full" />
        <span className="text-sm font-mono font-medium">{shortenAddress(address)}</span>
      </div>
    );
  }

  return (
    <Button
      onClick={onConnect}
      disabled={isConnecting}
      className="gap-2"
      data-testid="button-connect-wallet"
    >
      <Wallet className="w-4 h-4" />
      {isConnecting ? "Connecting..." : "Connect Wallet"}
    </Button>
  );
}
