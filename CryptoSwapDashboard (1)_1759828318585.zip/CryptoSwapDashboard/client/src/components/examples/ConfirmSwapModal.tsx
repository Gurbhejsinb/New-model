import ConfirmSwapModal from '../ConfirmSwapModal';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

export default function ConfirmSwapModalExample() {
  const [open, setOpen] = useState(false);
  
  return (
    <div className="p-4">
      <Button onClick={() => setOpen(true)}>Open Modal</Button>
      <ConfirmSwapModal
        open={open}
        onClose={() => setOpen(false)}
        onConfirm={() => {
          console.log('Swap confirmed');
          setOpen(false);
        }}
        fromAmount="0.5"
        toAmount="155.225"
        isConfirming={false}
        conversionRate={300}
      />
    </div>
  );
}
