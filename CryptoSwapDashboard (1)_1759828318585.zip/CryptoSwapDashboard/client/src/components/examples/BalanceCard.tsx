import BalanceCard from '../BalanceCard';

export default function BalanceCardExample() {
  return (
    <div className="space-y-4 p-4 max-w-md">
      <BalanceCard balance="1.2345" usdValue="620.50" />
      <BalanceCard balance="0.0000" />
    </div>
  );
}
