import SwapCard from '../SwapCard';
import { useState } from 'react';

export default function SwapCardExample() {
  const [fromAmount, setFromAmount] = useState('');
  const conversionRate = 300;
  const toAmount = fromAmount ? (parseFloat(fromAmount) * conversionRate).toFixed(2) : '';
  
  return (
    <div className="p-4 flex justify-center">
      <SwapCard
        fromAmount={fromAmount}
        toAmount={toAmount}
        onFromAmountChange={setFromAmount}
        balance="1.2345"
        onMaxClick={() => setFromAmount('1.2345')}
        onSwap={() => console.log('Swap clicked')}
        isConnected={true}
        isSwapping={false}
        conversionRate={conversionRate}
        isPriceLoading={false}
      />
    </div>
  );
}
