import TokenInput from '../TokenInput';
import { useState } from 'react';

export default function TokenInputExample() {
  const [value, setValue] = useState('');
  
  return (
    <div className="space-y-4 p-4 max-w-md">
      <TokenInput
        label="From"
        value={value}
        onChange={setValue}
        tokenSymbol="BNB"
        balance="1.2345"
        onMaxClick={() => setValue('1.2345')}
      />
      <TokenInput
        label="To"
        value="310.45"
        onChange={() => {}}
        tokenSymbol="USDT"
        readOnly
      />
    </div>
  );
}
