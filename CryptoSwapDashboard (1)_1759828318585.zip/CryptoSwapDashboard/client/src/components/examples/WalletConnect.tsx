import WalletConnect from '../WalletConnect';

export default function WalletConnectExample() {
  return (
    <div className="space-y-4 p-4">
      <WalletConnect 
        address={null}
        isConnecting={false}
        onConnect={() => console.log('Connect clicked')}
      />
      <WalletConnect 
        address={null}
        isConnecting={true}
        onConnect={() => console.log('Connect clicked')}
      />
      <WalletConnect 
        address="0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb0"
        isConnecting={false}
        onConnect={() => console.log('Connect clicked')}
      />
    </div>
  );
}
