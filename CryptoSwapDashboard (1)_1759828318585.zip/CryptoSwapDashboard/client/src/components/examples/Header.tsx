import Header from '../Header';

export default function HeaderExample() {
  return (
    <div>
      <Header
        address={null}
        isConnecting={false}
        onConnect={() => console.log('Connect clicked')}
      />
    </div>
  );
}
