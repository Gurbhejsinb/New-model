import WalletConnect from "./WalletConnect";

interface HeaderProps {
  address: string | null;
  isConnecting: boolean;
  onConnect: () => void;
}

export default function Header({ address, isConnecting, onConnect }: HeaderProps) {
  return (
    <header className="border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-white font-bold text-lg">JC</span>
            </div>
            <h1 className="text-xl font-bold">JC TRADERS CAPITAL</h1>
          </div>
          <WalletConnect
            address={address}
            isConnecting={isConnecting}
            onConnect={onConnect}
          />
        </div>
      </div>
    </header>
  );
}
