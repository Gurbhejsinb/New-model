import detectEthereumProvider from '@metamask/detect-provider';
import { BrowserProvider, Contract, parseUnits, formatUnits } from 'ethers';

const BSC_TESTNET_CHAIN_ID = '0x61'; // 97 in hex
const PANCAKE_ROUTER = '0x9ac64cc6e4415144c455bd8e4837fea55603e5c3';
const USDT_ADDRESS = '0x7ef95a0fee0dd31b22626fa2a769e3c2af2a9f5b';

export interface WalletState {
  address: string | null;
  balance: string;
  isConnected: boolean;
}

export async function connectWallet(): Promise<WalletState> {
  const provider = await detectEthereumProvider();
  
  if (!provider) {
    throw new Error('MetaMask is not installed');
  }

  const ethereum = provider as any;
  
  try {
    // Request account access
    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    
    // Check network
    const chainId = await ethereum.request({ method: 'eth_chainId' });
    
    if (chainId !== BSC_TESTNET_CHAIN_ID) {
      try {
        await ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: BSC_TESTNET_CHAIN_ID }],
        });
      } catch (switchError: any) {
        if (switchError.code === 4902) {
          await ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: BSC_TESTNET_CHAIN_ID,
              chainName: 'BSC Testnet',
              nativeCurrency: {
                name: 'BNB',
                symbol: 'BNB',
                decimals: 18
              },
              rpcUrls: ['https://data-seed-prebsc-1-s1.binance.org:8545/'],
              blockExplorerUrls: ['https://testnet.bscscan.com/']
            }]
          });
        } else {
          throw switchError;
        }
      }
    }

    const ethersProvider = new BrowserProvider(ethereum);
    const balance = await ethersProvider.getBalance(accounts[0]);
    
    return {
      address: accounts[0],
      balance: formatUnits(balance, 18),
      isConnected: true,
    };
  } catch (error) {
    throw error;
  }
}

export async function getBalance(address: string): Promise<string> {
  const provider = await detectEthereumProvider();
  if (!provider) throw new Error('MetaMask not found');
  
  const ethersProvider = new BrowserProvider(provider as any);
  const balance = await ethersProvider.getBalance(address);
  return formatUnits(balance, 18);
}

export async function executeSwap(fromAmount: string) {
  const provider = await detectEthereumProvider();
  if (!provider) throw new Error('MetaMask not found');
  
  const ethersProvider = new BrowserProvider(provider as any);
  const signer = await ethersProvider.getSigner();
  
  // Simple ABI for swap
  const routerABI = [
    'function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline) external payable returns (uint[] memory amounts)'
  ];
  
  const router = new Contract(PANCAKE_ROUTER, routerABI, signer);
  
  const amountIn = parseUnits(fromAmount, 18);
  const path = ['0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd', USDT_ADDRESS]; // WBNB -> USDT
  const to = await signer.getAddress();
  const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes
  
  const tx = await router.swapExactETHForTokens(
    0, // amountOutMin - set to 0 for demo (bad practice in production)
    path,
    to,
    deadline,
    { value: amountIn }
  );
  
  return tx.wait();
}

export function shortenAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}
