const COINGECKO_API = 'https://api.coingecko.com/api/v3/simple/price';

export async function fetchBNBPrice(): Promise<number> {
  try {
    const response = await fetch(
      `${COINGECKO_API}?ids=binancecoin&vs_currencies=usd`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch BNB price');
    }
    
    const data = await response.json();
    return data.binancecoin?.usd || 300; // Fallback to 300 if API fails
  } catch (error) {
    console.error('Error fetching BNB price:', error);
    return 300; // Fallback price
  }
}
