import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/Header";
import SwapCard from "@/components/SwapCard";
import BalanceCard from "@/components/BalanceCard";
import ConfirmSwapModal from "@/components/ConfirmSwapModal";
import { connectWallet, executeSwap, getBalance } from "@/lib/wallet";
import { fetchBNBPrice } from "@/lib/coinGecko";

export default function Home() {
  const { toast } = useToast();
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState<string>("0");
  const [fromAmount, setFromAmount] = useState<string>("");
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSwapping, setIsSwapping] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [bnbPrice, setBnbPrice] = useState<number>(300);
  const [isPriceLoading, setIsPriceLoading] = useState(true);

  // Fetch BNB price on mount and every 30 seconds
  useEffect(() => {
    const updatePrice = async () => {
      setIsPriceLoading(true);
      const price = await fetchBNBPrice();
      setBnbPrice(price);
      setIsPriceLoading(false);
    };

    updatePrice();
    const interval = setInterval(updatePrice, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const toAmount = fromAmount ? (parseFloat(fromAmount) * bnbPrice).toFixed(2) : "";
  const usdValue = balance ? (parseFloat(balance) * bnbPrice).toFixed(2) : "0";

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      const wallet = await connectWallet();
      setWalletAddress(wallet.address);
      setBalance(wallet.balance);
      toast({
        title: "Wallet Connected",
        description: "Successfully connected to BSC Testnet",
      });
    } catch (error: any) {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect wallet",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleMaxClick = () => {
    const maxAmount = Math.max(0, parseFloat(balance) - 0.01).toFixed(4);
    setFromAmount(maxAmount);
  };

  const handleSwapClick = () => {
    if (!walletAddress) {
      handleConnect();
      return;
    }
    setShowConfirmModal(true);
  };

  const handleConfirmSwap = async () => {
    setIsSwapping(true);
    try {
      await executeSwap(fromAmount);
      toast({
        title: "Swap Successful",
        description: `Swapped ${fromAmount} BNB for ${toAmount} USDT`,
      });
      setFromAmount("");
      setShowConfirmModal(false);
      
      if (walletAddress) {
        const newBalance = await getBalance(walletAddress);
        setBalance(newBalance);
      }
    } catch (error: any) {
      toast({
        title: "Swap Failed",
        description: error.message || "Transaction failed. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSwapping(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header
        address={walletAddress}
        isConnecting={isConnecting}
        onConnect={handleConnect}
      />

      <main className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        <div className="w-full max-w-md space-y-6">
          {walletAddress && (
            <BalanceCard balance={balance} usdValue={usdValue} />
          )}

          <SwapCard
            fromAmount={fromAmount}
            toAmount={toAmount}
            onFromAmountChange={setFromAmount}
            balance={balance}
            onMaxClick={handleMaxClick}
            onSwap={handleSwapClick}
            isConnected={!!walletAddress}
            isSwapping={isSwapping}
            conversionRate={bnbPrice}
            isPriceLoading={isPriceLoading}
          />

          <div className="text-center text-xs text-muted-foreground">
            <p>Powered by PancakeSwap Router</p>
            <p className="mt-1 font-mono">0x9ac6...5c3</p>
          </div>
        </div>
      </main>

      <ConfirmSwapModal
        open={showConfirmModal}
        onClose={() => setShowConfirmModal(false)}
        onConfirm={handleConfirmSwap}
        fromAmount={fromAmount}
        toAmount={toAmount}
        isConfirming={isSwapping}
        conversionRate={bnbPrice}
      />
    </div>
  );
}
