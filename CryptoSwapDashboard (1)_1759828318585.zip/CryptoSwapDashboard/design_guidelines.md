# Design Guidelines: Crypto Swap Dashboard (BSC Testnet)

## Design Approach
**Reference-Based Approach** inspired by leading DeFi platforms (PancakeSwap, SushiSwap, Uniswap) with clean, trust-focused design principles. This is a utility-first application where clarity, speed, and confidence in transactions are paramount.

## Core Design Principles
- **Trust Through Clarity**: Every element should communicate transparency and reliability
- **Efficiency First**: Minimal clicks to complete a swap, clear visual hierarchy
- **White Space Mastery**: Clean, uncluttered interface with generous padding
- **Feedback-Rich**: Immediate visual response to every user action

## Color Palette

### Light Mode (Primary)
- **Background**: 0 0% 100% (pure white)
- **Surface/Cards**: 0 0% 98% (off-white for depth)
- **Primary Brand**: 210 100% 50% (vibrant blue - trust/tech)
- **Success**: 142 76% 36% (green for confirmations)
- **Error**: 0 84% 60% (red for warnings)
- **Text Primary**: 0 0% 10% (near-black)
- **Text Secondary**: 0 0% 45% (muted gray)
- **Borders**: 0 0% 90% (subtle dividers)
- **Hover States**: 210 100% 45% (darker blue)

### Interactive States
- **Button Active**: Add subtle scale(0.98) transform
- **Input Focus**: 2px solid primary color border with subtle glow
- **Card Hover**: Slight shadow elevation increase

## Typography
- **Primary Font**: 'Inter' (Google Fonts) - modern, readable, DeFi standard
- **Numeric Font**: 'JetBrains Mono' for wallet addresses and token amounts (monospace clarity)

**Scale**:
- Headers: text-2xl to text-3xl, font-semibold
- Body: text-base, font-normal
- Labels: text-sm, font-medium, uppercase tracking-wide
- Numbers/Amounts: text-lg to text-2xl, font-medium
- Wallet Address: text-sm, font-mono

## Layout System
**Spacing Primitives**: Tailwind units of 4, 6, 8, 12, 16 (p-4, m-6, gap-8, py-12, etc.)

### Container Structure
- **Max Width**: max-w-md (448px) for swap card - focused, mobile-first
- **Page Container**: max-w-7xl with centered layout
- **Card Padding**: p-6 to p-8
- **Section Spacing**: space-y-6 between major sections

### Responsive Breakpoints
- Mobile: Full-width card with p-4
- Desktop: Centered card with shadow-2xl, max-w-md

## Component Library

### 1. Header/Navigation
- **Layout**: Flex justify-between, py-4, px-6
- **Logo/Brand**: Left-aligned, text-xl font-bold with primary color
- **Wallet Section**: Right-aligned with connection status
- **Connected State**: Show shortened address (0x1234...5678) with subtle background chip

### 2. Swap Card (Center Focus)
- **Container**: Rounded-2xl, bg-white, shadow-xl with subtle border
- **Internal Padding**: p-6 to p-8
- **Sections**: space-y-6 vertical rhythm

**Token Input Sections**:
- White/light gray background (nested cards)
- Rounded-xl borders
- Clear "From" and "To" labels with text-xs uppercase
- Large numeric inputs (text-2xl) with right-aligned max button
- Token selector dropdown (left side) with icon + symbol
- Balance display below: "Balance: X.XXXX BNB" in text-sm, text-secondary

**Swap Direction Icon**:
- Centered between inputs
- Circular button with border
- Rotate 90deg arrow icon
- Subtle hover effect (rotate interaction optional)

### 3. Buttons

**Primary (Connect/Swap)**:
- Full-width (w-full)
- Rounded-xl
- py-4, text-base font-semibold
- Primary blue background with white text
- Disabled state: opacity-50, cursor-not-allowed
- Hover: Slight brightness increase + shadow

**Secondary (Max, Cancel)**:
- Smaller, pill-shaped
- Border variant with primary color text
- px-4 py-2, text-sm

### 4. Wallet Balance Display
- Positioned below connect button when connected
- Card-style container with subtle border
- Display: "Your Balance" label + large BNB amount
- Include USD equivalent in smaller text-secondary

### 5. Conversion Rate Display
- Between swap inputs
- Small card or inline display: "1 BNB = 310.45 USDT"
- Text-sm with muted styling
- Include swap fee (0.3%) in even smaller text

### 6. Confirmation Modal
- **Overlay**: bg-black/50 backdrop blur
- **Modal Card**: max-w-sm, centered, rounded-2xl, bg-white, p-6
- **Content**: 
  - Title: "Confirm Swap" (text-xl font-bold)
  - Transaction summary in card format
  - From/To amounts prominently displayed
  - Estimated gas fee
  - Action buttons: Cancel (outline) + Confirm (primary)
- **Spacing**: space-y-4 between elements

### 7. Toast Notifications
- **Position**: Fixed top-right (top-4 right-4)
- **Variants**: Success (green), Error (red), Info (blue)
- **Structure**: Rounded-lg, p-4, shadow-lg with icon + message
- **Animation**: Slide-in from right, fade out after 5s
- **Max Width**: max-w-sm

### 8. Loading States
- Spinner icon for button loading states
- Skeleton loaders for balance/rate data
- Use primary color for all loading indicators

## Interaction Patterns

### Wallet Connection Flow
1. Prominent "Connect Wallet" button when disconnected
2. Click triggers MetaMask popup
3. On success: Show shortened address + balance card
4. On network mismatch: Auto-prompt to switch to BSC Testnet
5. Toast notification for all state changes

### Swap Flow
1. User enters amount in "From" field
2. Auto-calculate "To" amount with conversion rate
3. Validate: wallet connected, sufficient balance, valid amounts
4. "Swap" button enables only when valid
5. Click opens confirmation modal
6. Confirm triggers transaction
7. Show pending state with loading spinner
8. Success/error toast with transaction hash (if success)

### Input Validation
- Real-time balance checking
- Disable swap if amount > balance
- Show clear error states with red borders + helper text
- "Max" button pre-fills with available balance (minus gas)

## Animations (Minimal)
- Button hover: subtle scale and shadow transitions (200ms)
- Modal: fade-in backdrop + slide-up card (300ms ease-out)
- Toast: slide-in-right (250ms) + fade-out (500ms)
- Input focus: smooth border color transition (150ms)
- **Avoid**: Complex scroll animations, excessive motion

## Accessibility
- High contrast ratios (WCAG AA minimum)
- Focus states clearly visible with 2px outline
- Keyboard navigation support for all interactive elements
- ARIA labels for wallet addresses and transaction states
- Error messages announced to screen readers

## Images
**No hero images required** - this is a utility application focused on functionality. The visual impact comes from clean layout, precise typography, and thoughtful use of color for state communication.